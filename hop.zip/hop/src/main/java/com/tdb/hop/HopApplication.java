package com.tdb.hop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HopApplication {

	public static void main(String[] args) {
		SpringApplication.run(HopApplication.class, args);
	}
}
