package com.tdb.hookedonponics.hopreceiver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HopreceiverApplication {

	public static void main(String[] args) {
		SpringApplication.run(HopreceiverApplication.class, args);
	}
}
